    <?php $__env->startSection('content'); ?>
    <section>
    <h1 class="titulo">Pedido</h1>
    <div>
            <form>
        <div class="espaco">
            <input  class="form-control" type="text" placeholder="IdCategoria" name="txIdcategoria" value="Insira o ID da categoria"/>
        </div>
        <div class="espaco">
            <input  class="form-control" type="text" placeholder="IdProduto" name="txIdproduto" value="Insira o ID do produto"/>
        </div>
        <div class="espaco">
            <input  class="form-control" type="text" placeholder="Valor total da compra" name="txValor" value="Insira o valor"/>
        </div>
        <div class="espaco">
            <input class="btn btn-danger" type="submit" value="Salvar"/>
        </div>

        </form>
        </div>
            <?php $__currentLoopData = $pedido; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="space">
            <h1> IdPedido: <?php echo e($pe->idPedido); ?> </h1>
            <p> IdCategoria:<?php echo e($pe->idCategoria); ?> </p>
            <p> IdProduto: <?php echo e($pe->idProduto); ?> </p>
            <p> Valor total: <?php echo e($pe->valor_t); ?> </p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </section>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>