    <?php $__env->startSection('content'); ?>
    <section>
        <h1 class="titulo">Produto</h1>
        <div>
            <form>
        <div class="espaco">
            <input  class="form-control" type="text" placeholder="IdCategoria" name="txIdCategoria" value="Insira o ID da categoria"/>
        </div>        
        <div class="espaco">
            <input  class="form-control" type="text" placeholder="Produto" name="txProduto" value="Insira um produto"/>
        </div>
        <div class="espaco">
            <input  class="form-control" type="text" placeholder="Valor" name="txValor" value="Insira o valor"/>
        </div>
        <div class="espaco">
            <input class="btn btn-danger" type="submit" value="Salvar"/>
        </div>

            </form>
        </div>
            <?php $__currentLoopData = $produto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="space">
            <h1> IdProduto: <?php echo e($p->idProduto); ?> </h1>
            <p> IdCategoria: <?php echo e($p->idCategoria); ?> </p>
            <p> Produto: <?php echo e($p->produto); ?> </p>
            <p> Valor: <?php echo e($p->valor); ?> </p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </section>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>