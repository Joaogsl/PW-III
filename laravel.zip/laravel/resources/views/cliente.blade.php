@extends('template.default')
    @section('content')
    <section>
        <h1 class="titulo">Cliente</h1>
        <div>
            <form action="{{url('/cliente/inserir')}}" method="post">
            {{csrf_field()}}
        <div class="espaco">
            <input  class="form-control" type="text" placeholder="Nome" name="txNome" value="Insira seu nome"/>
        </div>
        <div class="espaco">
            <input  class="form-control" type="text" placeholder="Data de nascimento" name="txData" value="Insira sua data de nasc - escreva em XXXX-XX-XX"/>
        </div>
        <div class="espaco">
            <input  class="form-control" type="text" placeholder="EstadoCiv" name="txCiv" value="Insira seu Estado Civil"/>
        </div>
        <div class="espaco">
            <input  class="form-control" type="textarea" placeholder="Endereço" name="txEnd" value="Insira seu endereço"/>
        </div>
        <div class="espaco">
            <input  class="form-control" type="number" placeholder="Número" name="txNum" value="Insira seu número"/>
        </div>
        <div class="espaco">
            <input  class="form-control" type="text" placeholder="Complemento" name="txCom" value="Insira seu complemento"/>
        </div>
        <div class="espaco">
            <input  class="form-control" type="number" placeholder="CEP" name="txCEP" value="Insira seu CEP"/>
        </div>
        <div class="espaco">
            <input  class="form-control" type="text" placeholder="Cidade" name="txCid" value="Insira cidade"/>
        </div>
        <div class="espaco">
            <input  class="form-control" type="text" placeholder="Estado" name="txEst" value="Insira estado"/>
        </div>
        <div class="espaco">
            <input  class="form-control" type="text" placeholder="RG" name="txRG" value="Insira seu RG"/>
        </div>
        <div class="espaco">
            <input  class="form-control" type="number" placeholder="CPF" name="txCPF" value="Insira seu CPF"/>
        </div>
        <div class="espaco">
            <input  class="form-control" type="email" placeholder="Email" name="txEmail" value="Insira seu email"/>
        </div>
        <div class="espaco">
            <input  class="form-control" type="text" placeholder="Telefone" name="txTel" value="Insira seu telefone"/>
        </div>
        <div class="espaco">
            <input  class="form-control" type="text" placeholder="Celular" name="txCel" value="Insira seu celular"/>
        </div>
        <div class="espaco">
            <input class="btn btn-danger" type="submit" value="Salvar"/>
        </div>

            </form>
        </div>
                @foreach($cliente as $pe)
                <div class="space">
                <h1> IdCliente: {{$pe->idCliente}} </h1>
                <p> Nome: {{$pe->nome}} </p>
                <p> Data de Nascimento: {{$pe->dtNasc}} </p>
                <p> Estado Civil: {{$pe->estadoCivil}} </p>
                <p> Endereço: {{$pe->endereco}} </p>
                <p> Número: {{$pe->numero}} </p>
                <p> Complemento: {{$pe->complemento}} </p>
                <p> CEP: {{$pe->cep}} </p>
                <p> Cidade: {{$pe->cidade}} </p>
                <p> Estado: {{$pe->estado}} </p>
                <p> RG: {{$pe->Rg}} </p>
                <p> CPF: {{$pe->cpf}} </p>
                <p> Email: {{$pe->email}} </p>
                <p> Telefone: {{$pe->fone}} </p>
                <p> Celular: {{$pe->celular}} </p>
                </div>
                @endforeach
        
    </section>

    @endsection